const data=[
    {
        id:1,
        name:"Aman",
        address:"12930 marco",
        maths:81,
        english:82,
        science:97,
        sanskrit:86,
        evs:96,
        average:88.4,
        totalmarks:442,
        grade:'B',
    }
]

module.exports=data;